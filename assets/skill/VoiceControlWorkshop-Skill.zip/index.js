// This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
// Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
// session persistence, api calls, and more.
const Alexa = require('ask-sdk-core');
let AWS = require('aws-sdk');

//TODO: UPDATE ME HERE
const IOT_BROKER_ENDPOINT = "XXXXXXX-ats.iot.us-east-1.amazonaws.com";
const IOT_BROKER_REGION = "us-east-1";
const IOT_THING_NAME = "XXXXXXX";

AWS.config.region = IOT_BROKER_REGION;

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },

    handle(handlerInput) {
        const speechText = 'Welcome to the Raspberry Pi LED control app. What would you like to do?';
        const repromptText = 'You can say: turn the red led on ';
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(repromptText)
            .withSimpleCard('LED Control', speechText)
            .getResponse();
    }
};



const LEDControllerIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'LEDControlIntent';
    },
    handle(handlerInput) {

        let color = handlerInput.requestEnvelope.request.intent.slots.color.value;
        let state = handlerInput.requestEnvelope.request.intent.slots.state.value;
        let speechText = '';
        if (state === 'on' || state === 'off') {
            if (color === 'red' || color === 'green' || color === 'blue') {
                speechText = "The " + color + " LED is " + state;
                var newState = {
                    'color': color,
                    'state': state
                };
                updateShadow(newState);
            } else {
                speechText = 'Sorry, I don\'t know this LED color';
            }
        } else {
            speechText = 'Sorry, I don\'t know this state';
        }

        return handlerInput.responseBuilder
            .speak(speechText)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const SwitchCheckIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'SwitchCheckIntent';
    },
    handle(handlerInput) {

        let params = {
            "thingName": IOT_THING_NAME
        };
        let iotData = new AWS.IotData({
            endpoint: IOT_BROKER_ENDPOINT
        });

        return new Promise((resolve, reject) => {
            iotData.getThingShadow(params, function (err, data) {
                let speechText = '';
                if (err) {
                    console.log("Error updating thing shadow" + err);
                    speechText = 'Sorry, there is an error';
                } else {
                    var payload = JSON.parse(data.payload.toString());
                    console.log("PAYLOAD", payload);
                    if (payload.state && payload.state.reported && payload.state.reported.switch != null) {
                        speechText = "The switch is " + payload.state.reported.switch;
                    } else {
                        speechText = 'Sorry, the switch state is undefined';
                    }
                }
                console.log("speechText", speechText);
                resolve(handlerInput.responseBuilder
                    .speak(speechText)
                    //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
                    .withSimpleCard('Switch Status', speechText)
                    .getResponse());
            })
        });

    }
};

// Updates the shadow on the IOT
function updateShadow(desiredState) {
    var paramsUpdate = {
        "thingName": IOT_THING_NAME,
        "payload": JSON.stringify({
            "state": {
                "desired": desiredState
            }
        })
    };
    var iotData = new AWS.IotData({
        endpoint: IOT_BROKER_ENDPOINT
    });
    iotData.updateThingShadow(paramsUpdate, function (err, data) {
        if (err) {
            console.log("Error updating thing shadow" + err);
        } else {
            console.log("updated thing shadow " + IOT_THING_NAME + ' to state ' + paramsUpdate.payload);
        }
    });
}


const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speechText = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent' ||
                handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speechText = 'Goodbye!';
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = handlerInput.requestEnvelope.request.intent.name;
        const speechText = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speechText)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.message}`);
        const speechText = `Sorry, I couldn't understand what you said. Please try again.`;

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};

// This handler acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        LEDControllerIntentHandler,
        SwitchCheckIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler) // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    .addErrorHandlers(
        ErrorHandler)
    .lambda();